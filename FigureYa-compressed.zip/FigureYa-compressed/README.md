# FigureYa-compressed
All FigureYa modules are available as individually compressed zip files for convenient offline use. 
